# Design QA — 三维动效修正 v2

2026-10-19。当前验收覆盖个人档案原型的核心运动与既定配色；不代表完整官网已开发。v1 记录保留在 `qa/motion-v2/design-qa-v1.md`，其中的2.5D结论已被用户反馈推翻。

## 参考与证据

- 视觉源：`../design/stage-03-profile/screens/01-profile-light.png`，1586×992。明确保留颜色、左影像右资料、字段、页签与操作层级。
- 动效源：实际访问原站 https://rhine.lubeiluchen.cc/?scene=archive ，查看并采集 `qa/motion-v2/reference/` 的阵列、0／700／1700／3000／4500／6000ms阶段。第一方参数说明见 `../design/stage-04-motion/REFERENCE.md`。
- 本地：`qa/motion-v2/archive.png`、`stage-0.png`、`stage-0.6.png`、`stage-1.4.png`、`stage-3.png`、`stage-5.png`、`stage-6.5.png`、`returned.png`。桌面实际视口1586×992，DPR1，匿名初始档案。
- 已逐一查看原站3000／6000ms、当前连接／清晰阶段、当前阵列、桌面与移动截图，并对照所选稿。不用原站颜色或内容作本地视觉目标。

## 已修复的问题

1. P1 动效结构不符：移除平面图层入场，用真实三维阵列、选中模型垂直抽取和独立相机运动。提取过程模型Y轴角度保持0，镜头实际移动。
2. P2 原版节奏被任意缩短：采用原始阻尼与条件解密控制器。镜头及模型达到门槛后才计时；扫描连接、停留、收拢、照片由上至下清晰与正文遮罩联动。
3. P2 返回顺序：实际鼠标拖动后自动验证保高对齐，rotation归零后才下降。
4. P2 窄屏构图：修复viewport变化时aspect更新不同步；<=950px镜头与UI统一改为上下布局。检查390×844与768×1024，照片完整、正文与操作可达；增加正文全宽纸色底，修正其伪元素曾造成的10px横向溢出。
5. 核验工具修正：等待纹理loaded，而非环境贴图初始化drawCalls；跳过恢复暂停的QA场景，便于后续真实鼠标交互。

## 验证结果

- `qa/motion-v2/motion-checks.json`：6个固定模拟时刻，真实模型与镜头状态、扫描线、清晰度和geometry drawCalls均通过；返回顺序、页签、窄屏、无控制台异常通过。
- `qa/browser-checks.json`：13项通过；四视口无横向溢出；编辑、刷新、重置；键盘页签；跳过重播；用户及系统减少动态；影像弹窗Escape；缺图错误。页面／控制台错误数组为空。
- `qa/desktop.png`、`qa/laptop.png`、`qa/tablet.png`、`qa/mobile.png` 为本轮实际截图。较矮笔记本允许垂直滚动访问底部操作。
- TypeScript检查与生产构建通过。构建的单个Three.js应用包约794kB／gzip215kB，Vite有体积提示；后续正式上线可按页面分包，目前未声称已完成性能专项验收。

## 保真与剩余范围

字体层级、左右构图、双列字段、页签、按钮和原稿灰白／近黑／暖色标记保持。生成照片的脸部和裁切、重建三维框的厚度、玻璃反射及光照与静态稿有P3差异。档案模型没有原站内部机械结构，开场影片、音频、所有旧卡副本及波场调度未复刻，详见MOTION_SPEC.md；本轮不宣称逐像素或全站复刻。

核心运动问题及响应式P2均已修复，无剩余阻断本轮核心动效评审的问题。真实认证、数据库与全站其他栏目不在此原型范围。

final result: passed (core archive motion adaptation and selected palette; scope above)
