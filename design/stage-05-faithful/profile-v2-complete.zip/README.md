# 教官大队｜个人档案动效原型

本地预览：http://127.0.0.1:4173/ 。服务器已启动。当前为独立个人档案前端原型，真实账号与数据库未接入。

## 设计约束

保留第1张个人档案稿 `../design/stage-03-profile/screens/01-profile-light.png` 的配色与阅读构图。RhineLabUI 只作为动效参考。此前所有方案保留。

## 本轮修正

原来的 CSS/WAAPI 2.5D 图片动画与原作有明显差异，已被 Three.js 三维场景替换。初始展示档案阵列，点击「读取档案」后垂直抽取、相机移向详情、模型空间扫描线会合与收拢、照片从上到下清晰、文字遮罩联动退开。横拖可观察角度；返回先对齐再下降。可跳过、重播或减少动态。

关键曲线和解密控制器直接基于原项目 MIT 源码，出处及改编范围见 [MOTION_SPEC.md](MOTION_SPEC.md) 与 [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)。没有声称完整复制原作的模型、光学效果、开场影片或声效。

## 可操作范围

- 档案分类选择、进入、拖动、返回、重播、跳过、减少动态，响应系统偏好。
- 基本资料／训练记录／个人荣誉页签及方向键、Home/End导航。
- 编辑虚构昵称和简介，仅保存在本浏览器，可刷新保留、重置。数据接口在 `src/data.ts`。
- 影像放大、Escape关闭、弹窗焦点管理；其余导航说明对应页面的待开发范围。

演示身份和影像均为虚构。前端「仅本人可见」标记是拟议产品语义，尚无真实身份鉴别和服务端访问控制。不要输入真实敏感信息。

## 技术与资产

React、TypeScript、Three.js、CSS、Phosphor 图标。三维生命周期与运动在 `src/motion/archive-scene.ts`；来源曲线、解密与正文揭示独立保存。所有素材本地加载。

`public/assets/member-photo.png` 是内置 Image Gen 根据选定虚构人物摄影生成的无框照片纹理；真实档案框、玻璃、固定件、阵列和扫描线由 Three.js 渲染。旧透明板 `member-archive.png` 留作影像查看素材。没有使用参考项目的标志、人物、世界观模型或音频。

## 验证

- `npm run check`、`npm run build`。
- `scripts/verify-motion-v2.mjs`：真实三维状态与阶段截图、拖动后先对齐再下降、响应式检查。
- `scripts/verify-profile.mjs`：独立 Playwright/Edge 会话；编辑刷新、键盘、减少动态、图片失败及四种视口。
- 环境变量 `PROFILE_QA_MODULES` 指向含 Playwright 的目录，`PROFILE_QA_CHANNEL=msedge`。
- [视觉验收](design-qa.md) 与 `qa/motion-v2/` 保存当前证据；旧版证据仅用于追溯。
