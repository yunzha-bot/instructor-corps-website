# 档案动效规格 v2

用户约束：第1张档案构图及当前颜色保留；RhineLabUI 参考目标是动效。v1 的 CSS/WAAPI 2.5D 实现已弃用，不能作为动效验收依据。

## 已验证的第一方参考

2026-10-19 实际打开 https://rhine.lubeiluchen.cc/?scene=archive ，采集进入详情后的阶段截图，保存在 `qa/motion-v2/reference/`。源码详细分析、参数与链接见 `../design/stage-04-motion/REFERENCE.md`。原站截图与本地截图只比较运动阶段，不比较配色和内容。

源文件：[motion.ts](https://github.com/LBEILC/RhineLabUI/blob/main/src/motion.ts)、[decryption.ts](https://github.com/LBEILC/RhineLabUI/blob/main/src/decryption.ts)、[scene.ts](https://github.com/LBEILC/RhineLabUI/blob/main/src/scene.ts)、[document-decryption.ts](https://github.com/LBEILC/RhineLabUI/blob/main/src/document-decryption.ts)。保留 MIT 许可。

## 实际状态与联动

1. `archive`：9列×32行真实三维阵列；类别为本人基本资料／训练／荣誉，绝不表示可访问其他队员私档。悬停增高 .28，rate14；分类与阵列轨道联动。
2. `opening`：档案只垂直抽取（预览 .4 → 4.05，带速度的临界阻尼 rate4.2），不是自动旋转图片。镜头目标 `smooth((lift-.8)/2.4)`，detail rate2.8。视向由59°／19°混至归一化向量(-.277,.238,.931)，距离140→72，镜头追赶rate5。
3. 解密门槛：detail>.78且lift>3.3。直接采用原控制器的单调三次Hermite采样：等待、两端会合、连接停留、收拢、从上向下显露，总计约3.6267秒（从门槛满足后算）。线段真实位于模型空间，随镜头投影；纹理清晰度shader与正文黑条由同一控制器驱动。正文揭示使用来源算法，适配本项目DOM选择器。
4. `reading`：允许横拖观察，deltaX*.004；本原型限制±.45弧度。无拖动时不自动旋转档案。文字保持可选中、键盘可操作的DOM。
5. `returning`：有旋转时保持绝对高度，以exp(-7dt)归零，阈值 .001；对齐后才下降，镜头退回阵列。重播经过完整归位后重新读取。
6. 跳过／减少动态直接进入阅读，不强迫观看长动画；重播仅由用户触发。

## 有意改编与保真边界

- 最终桌面垂直跨度4.95，以符合用户所选人物档案稿；原站约5.9。窄屏<=950px改为上方摄影、下方资料，镜头同步重构图。配色沿用选定稿。
- 模型是新建的档案框、玻璃层、照片和固定件；材质、照明、邻卡细节及摄影裁切不是原站逐像素复刻。没有复制原作logo、人物、完整模型、音频、开场影片。
- 阵列切换采用单个选中模型与轨道；未复制原作所有旧卡独立副本和波场调度。这不影响本轮重点的抽取、镜头、扫描、显露和顺序归位。
- 解密是视觉隐喻，不是实际安全机制。正式隐私必须依靠后端鉴权。

## 自动检查的边界

`window.__archiveScene.inspectAt(t)` 仅供开发环境截图，将真实场景推进到固定模拟时间；`snapshot()` 返回实际模型、镜头、解密与绘制状态。测试还使用真实鼠标拖动验证返回顺序。阶段截图需人工查看，不能只用“动画结束”判定与参考一致。
