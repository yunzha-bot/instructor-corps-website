# Prototype Instructions

## Confirmed design

Use `../design/stage-03-profile/screens/01-profile-light.png` for the personal-profile layout and current colors. The user selected this exact first image and explicitly kept its colors. RhineLabUI is the motion reference, not an instruction to adopt its palette. Motion adaptation and scope live in `MOTION_SPEC.md`; consult it before changing archive extraction, reveal, return or replay behavior. Preserve all earlier design drafts.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

## Motion fidelity correction (2026-10-19)

The user rejected the flat CSS/WAAPI animation as unlike RhineLabUI. Use actual Three.js archive geometry, vertical extraction plus camera movement, source-timed scan/decryption and align-before-descent return. Do not restore the discarded 2.5D shortcut. Preserve the selected first mock's palette. Current authoritative details: MOTION_SPEC.md v2; source attribution: THIRD-PARTY-NOTICES.md. Phase screenshots and real interaction checks are required; an animation-completed assertion alone is insufficient. User has authorized isolated Playwright browser QA.
